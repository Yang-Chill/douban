package fm.douban.util;

public class FavoriteUtil {

    public final static String TYPE_RED_HEART = "redHeart";
    public final static String ITEM_TYPE_SONG = "song";
    public final static String ITEM_TYPE_SINGER = "singer";
    public final static String ITEM_TYPE_MHZ = "mhz";
    public final static String ITEM_TYPE_COLLECTION = "collection";

}
