package fm.douban.util;

public class SubjectUtil {

    public static String TYPE_MHZ = "mhz";
    public static String TYPE_COLLECTION = "collection";
    public static String TYPE_SUB_ARTIST = "artist";
    public static String TYPE_SUB_MOOD = "mood";
    public static String TYPE_SUB_AGE = "age";
    public static String TYPE_SUB_STYLE = "style";

}
