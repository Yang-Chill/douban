package fm.douban.app.control;

import fm.douban.model.*;
import fm.douban.param.SongQueryParam;
import fm.douban.service.*;
import fm.douban.util.FavoriteUtil;
import fm.douban.util.SubjectUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
public class MainControl {
    @Autowired
    SongService songService;
    @Autowired
    SingerService singerService;
    @Autowired
    SubjectService subjectService;
    @Autowired
    UserService userService;
    @Autowired
    FavoriteService favoriteService;

    private static final Logger LOG = LoggerFactory.getLogger(MainControl.class);

    @GetMapping("/index")
    public String index(Model model, HttpServletRequest request, HttpServletResponse response) {
        setPlayer(model);
        setMhz(model);
        setCollection(model);
        setFavorite(model, request);
        return "firstpage/index";
    }

    private void setPlayer(Model model) {
        SongQueryParam songQueryParam = new SongQueryParam();
        songQueryParam.setPageSize(1);
        songQueryParam.setPageNum(1);
        Page<Song> songPage = songService.list(songQueryParam);
        List<Song> songs = songPage.getContent();
        Song song = songs.get(0);
        List<String> singerIds = song.getSingerIds();
        List<Singer> singers = new ArrayList<>();
        for (String singerId : singerIds) {
            Singer singer = singerService.get(singerId);
            singers.add(singer);
        }
        // player相关
        model.addAttribute("song",song);
        model.addAttribute("singers",singers);
    }

    private void setMhz(Model model) {
        MhzViewModel moodMhz = new MhzViewModel();
        moodMhz.setTitle("心情/场景");
        moodMhz.setSubjects(subjectService.getSubjects(SubjectUtil.TYPE_MHZ, SubjectUtil.TYPE_SUB_MOOD));
        MhzViewModel ageMhz = new MhzViewModel();
        ageMhz.setTitle("语言/年代");
        ageMhz.setSubjects(subjectService.getSubjects(SubjectUtil.TYPE_MHZ, SubjectUtil.TYPE_SUB_AGE));
        MhzViewModel styleMhz = new MhzViewModel();
        styleMhz.setTitle("风格/流派");
        styleMhz.setSubjects(subjectService.getSubjects(SubjectUtil.TYPE_MHZ, SubjectUtil.TYPE_SUB_STYLE));
        List<MhzViewModel> allMhzs = new ArrayList<>();
        allMhzs.add(moodMhz);
        allMhzs.add(ageMhz);
        allMhzs.add(styleMhz);

        List<Subject> artistDatas = subjectService.getSubjects(SubjectUtil.TYPE_MHZ, SubjectUtil.TYPE_SUB_ARTIST);

        // explore相关：兆赫
        model.addAttribute("artistDatas",artistDatas);
        model.addAttribute("mhzViewModels",allMhzs);
    }

    private void setCollection(Model model) {
        List<Subject> collections = subjectService.getSubjects(SubjectUtil.TYPE_COLLECTION);

        class CollectionData extends Subject{
            private List<String> songInfos;

            public List<String> getSongInfos() {
                return this.songInfos;
            }
            public void setSongInfos(List<String> songInfos) {
                this.songInfos = songInfos;
            }
        }

        List<CollectionData> collectionDatas = new ArrayList<>();

        for (Subject collection : collections) {

            CollectionData data = new CollectionData();
            data.setId(collection.getId());
            data.setMaster(collection.getMaster());
            data.setCover(collection.getCover());
            data.setName(collection.getName());
            data.setCollectedCount(collection.getCollectedCount());
            data.setSongsCount(collection.getSongsCount());

            List<String> songInfos = new ArrayList<>();
            for (int i=0; i<3; i++) {
                Song songData = songService.get(collection.getSongIds().get(i));
                String songInfo = songData.getName() + " - ";
                if (songData.getSingerIds().size() == 0) {
                    continue;
                }
                Singer singer = singerService.get(songData.getSingerIds().get(0));
                songInfo += singer.getName();
                songInfos.add(songInfo);
            }
            data.setSongInfos(songInfos);
            collectionDatas.add(data);
        }
        // explore相关：歌单
        model.addAttribute("collections", collectionDatas);
    }

    private void setFavorite(Model model, HttpServletRequest request) {
        HttpSession session = request.getSession();
        UserLoginInfo user = (UserLoginInfo)session.getAttribute("userLoginInfo");
        String userId = user.getUserId();
        Favorite fav = new Favorite();
        fav.setId(userId);
        fav.setType(FavoriteUtil.TYPE_RED_HEART);

        List<Favorite> favs = favoriteService.list(fav);
        List<Song> fsongs = new ArrayList<>();
        if (favs != null && !favs.isEmpty()) {
            for (Favorite tfav : favs) {
                if (FavoriteUtil.TYPE_RED_HEART.equals(tfav.getType()) && FavoriteUtil.ITEM_TYPE_SONG.equals(
                        tfav.getItemType())) {
                    Song fsong = songService.get(tfav.getItemId());
                    if (fsong != null) {
                        fsongs.add(fsong);
                    }
                }
            }
        }
        //explore相关：我的
        model.addAttribute("favorites", favs);
        model.addAttribute("songs", fsongs);
    }

    @GetMapping("/fav")
    @ResponseBody
    public Map doFav(@RequestParam("itemId") String itemType, @RequestParam("itemType") String itemId,
                 HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        UserLoginInfo user = (UserLoginInfo)session.getAttribute("userLoginInfo");
        String userId = user.getUserId();

        Map result = new HashMap();
        Favorite fav = new Favorite();
        fav.setId(userId);
        fav.setItemId(itemId);
        fav.setItemType(itemType);
        List<Favorite> favs = favoriteService.list(fav);
        if (favs.size()>0) {
            favoriteService.delete(fav);
        } else {
            favoriteService.add(fav);
        }
        result.put("message", "successful");
        return result;
    }

    //首页搜索逻辑
    @GetMapping("/index/searchContent")
    @ResponseBody
    public Map indexSearch(@RequestParam("keyword") String keyword) {

        List<Singer> singers = new ArrayList<>();
        List<Song> songs = new ArrayList<>();
        List<Subject> collections = new ArrayList<>();
        List<Subject> mhzs = new ArrayList<>();

        for (Singer singer : singerService.getAll()) {
            if (singer.getName().contains(keyword)) {
                singers.add(singer);
            }
        }

        SongQueryParam param = new SongQueryParam();
        Page<Song> allSongs = songService.list(param);
        for (Song song : allSongs.getContent()) {
            if (song.getName().contains(keyword)) {
                songs.add(song);
            }
        }

        for (Subject subject : subjectService.getSubjects(SubjectUtil.TYPE_MHZ)) {
            if (subject.getName().contains(keyword)) {
                mhzs.add(subject);
            }
        }

        for (Subject subject : subjectService.getSubjects(SubjectUtil.TYPE_COLLECTION)) {
            if (subject.getName().contains(keyword)) {
                collections.add(subject);
            }
        }

        Map map = new HashMap<>();
        map.put("singers", singers);
        map.put("songs", songs);
        map.put("mhzs", mhzs);
        map.put("collections", collections);

        return map;

    }

}
